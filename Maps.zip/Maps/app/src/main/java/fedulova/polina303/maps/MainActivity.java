package fedulova.polina303.maps;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import fedulova.polina303.maps.databinding.ActivityMainBinding;
import fedulova.polina303.maps.databinding.AddPointDialogBinding;
import fedulova.polina303.maps.databinding.CashDialogBinding;
import fedulova.polina303.maps.model.PointDTO;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private MapViewStateDatabase db;
    private Boolean isAdding = false;
    private Boolean isDeleting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        db = new MapViewStateDatabase(this.getApplicationContext());

        binding.map.refreshMap(db.getPoints());

        binding.map.setListener(new OnClickToMap() {
            @Override
            public void onClick(Float x, Float y) {
                if (isAdding) { //режим добавления точки
                    openAddPointDialog(x, y);
                }
            }

            @Override
            public void onPointClick(PointDTO point) {
                if (isDeleting) {
                    db.deletePoint(point.id);
                    binding.map.refreshMap(db.getPoints());
                    isDeleting = false;
                }
            }

            @Override
            public void onMove() {
                binding.map.refreshMap(db.getPoints());
            }
        });

        binding.buttonPlus.setOnClickListener(v -> {
            if (binding.map.current_level_index == binding.map.levels.length - 1) return;
            binding.map.offset_x *= 2.0f;
            binding.map.offset_y *= 2.0f;
            binding.map.offset_x -= binding.map.width / 2.0f;
            binding.map.offset_y -= binding.map.height / 2.0f;
            binding.map.current_level_index++;
            binding.map.invalidate();
            binding.map.saveMapViewState();
        });

        binding.buttonMinus.setOnClickListener(v -> {
            if (binding.map.current_level_index == 0) return;
            binding.map.offset_x += binding.map.width / 2.0f;
            binding.map.offset_y += binding.map.height / 2.0f;
            binding.map.offset_x /= 2.0f;
            binding.map.offset_y /= 2.0f;
            binding.map.current_level_index--;
            binding.map.invalidate();
            binding.map.saveMapViewState();
        });

        binding.buttonCashSave.setOnClickListener(v -> {
            openCashDialog();
        });

        binding.clearCacheButton.setOnClickListener(v -> {
                binding.map.clearCache();
            binding.map.invalidate();
            Toast.makeText(this, "Кэш очищен", Toast.LENGTH_SHORT).show();
        });

        binding.btnPlusPoint.setOnClickListener(v -> {
            isDeleting = false;
            isAdding = true;
        });

        binding.btnDeletePoint.setOnClickListener(v -> {
            isAdding = false;
            isDeleting = true;
        });
    }

    private long parseCacheExpirationTime(String cacheTimeText) {
        // Реализуйте парсинг времени кэширования из текста и преобразование его в миллисекунды
        // Верните -1, если ввод некорректен

        return -1;
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Сохраняем данные в базу данных при приостановке активности
        binding.map.saveMapViewState();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Восстанавливаем данные из базы данных при восстановлении активности
        binding.map.restoreMapViewState();
    }

    private void openCashDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this).create();

        View dialogView = getLayoutInflater().inflate(R.layout.cash_dialog, null);
        CashDialogBinding dialogBinding = CashDialogBinding.bind(dialogView);

        dialogBinding.tvTitle.setText("Введите время кэширования");

        dialogBinding.btnAdd.setOnClickListener(view -> {
            if (!dialogBinding.etTime.getText().toString().isEmpty()) {
                String cacheTimeText = dialogBinding.etTime.getText().toString();
                long cacheExpirationTime = parseCacheExpirationTime(cacheTimeText);
                Toast.makeText(this, "Некорректное значение времени кэширования", Toast.LENGTH_SHORT).show();
            }
        });
        dialog.setView(dialogView);
        dialog.getWindow().setLayout(300, 300);
        dialog.show();
    }

    private void openAddPointDialog(Float x, Float y) {

        AlertDialog dialog = new AlertDialog.Builder(this).create();

        View dialogView = getLayoutInflater().inflate(R.layout.add_point_dialog, null);
        AddPointDialogBinding dialogBinding = AddPointDialogBinding.bind(dialogView);

        dialogBinding.tvTitle.setText("Введите название точки");

        dialogBinding.btnAdd.setOnClickListener(view -> {
            if (!dialogBinding.etName.getText().toString().isEmpty()) {
                db.addPoint(dialogBinding.etName.getText().toString(), x, y);
                binding.map.refreshMap(db.getPoints());
                isAdding = false;
                dialog.dismiss();//закрыть диалог
            }
        });
        dialog.setView(dialogView);
        dialog.getWindow().setLayout(300, 300);
        dialog.show();
    }
}