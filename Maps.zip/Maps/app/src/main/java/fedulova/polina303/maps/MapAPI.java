package fedulova.polina303.maps;


import java.util.List;

import fedulova.polina303.maps.model.CoordinateDTO;
import fedulova.polina303.maps.model.MapItemDTO;
import fedulova.polina303.maps.model.PointDTO;
import fedulova.polina303.maps.model.TileDTO;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface MapAPI {

    @GET("/raster")
    Call<List<MapItemDTO>> getRaster();

    @GET("/raster/{level}/{x}-{y}")
    Call<TileDTO> getTile(
            @Path("level") Integer rasterLevel,
            @Path("x") Integer xPos,
            @Path("y") Integer yPos
    );

    @GET("/coastline/{level}")
    Call<List<List<CoordinateDTO>>> getCoastline(
            @Path("level") Integer rasterLevel,
            @Query("lat0") Float lat0,
            @Query("lon0") Float lan0,
            @Query("lat1") Float lat1,
            @Query("lon1") Float lan1
    );

    @GET("/marker")
    Call<PointDTO> getMarker(
            @Query("level") Integer rasterLevel,
            @Query("lat0") Integer lat0,
            @Query("lon0") Integer lan0,
            @Query("lat1") Integer lat1,
            @Query("lon1") Integer lan1
    );

    @PUT("/marker")
    Call<Void> addMarker(
            @Query("lat") Integer lat,
            @Query("lon") Integer lan,
            @Query("name") String nameMarker
    );

    @POST("/marker")
    Call<Void> updateMarker(
            @Query("id") Integer idMarker,
            @Query("name") String nameMarker
    );

    @DELETE("/marker")
    Call<Void> deleteMarker(
            @Query("id") Integer idMarker
    );
}
