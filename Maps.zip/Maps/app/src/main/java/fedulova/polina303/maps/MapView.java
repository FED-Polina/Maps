package fedulova.polina303.maps;

import static java.lang.Math.abs;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

import fedulova.polina303.maps.model.CoordinateDTO;
import fedulova.polina303.maps.model.PointDTO;
import fedulova.polina303.maps.model.Tile;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MapView extends SurfaceView {
    private static final String TABLE_TILES = "tiles";
    private MapViewStateDatabase dbHelper;
    private SQLiteDatabase db;
    ArrayList<Tile> tiles = new ArrayList<Tile>(); //массив объектов
    private ExecutorService tileLoadExecutor;
    Handler mainThreadHandler = new Handler(Looper.getMainLooper());

    Tile getTile(int x, int y, int scale) {
        for (int i = 0; i < tiles.size(); i++) {
            Tile t = tiles.get(i);
            if (t.x == x && t.y == y && t.scale == scale) return t;
        }
        Tile nt = new Tile(x, y, scale);
        tiles.add(nt);
        return nt;
    }

    float last_x;
    float last_y;
    int current_level_index = 0;

    int[] levels = new int[]{16, 8, 4, 2, 1};
    int[] x_tiles = new int[]{54, 108, 216, 432, 864};
    int[] y_tiles = new int[]{27, 54, 108, 216, 432};

    int tile_width = 100;
    int tile_height = 100;

    float offset_x = 0.0f;
    float offset_y = 0.0f;
    Paint p;
    int width, height;

    private OnClickToMap listener;
    private ArrayList<PointDTO> mapPoints = new ArrayList<>();
    private List<List<CoordinateDTO>> coastlineCoordinates = new ArrayList<>();
    private MapAPI api = ApiBuilder.getAPI();
    private Canvas map = new Canvas();

    public void setListener(OnClickToMap newListener) {
        this.listener = newListener;
    }

    public void clearCache() {
        if (tileLoadExecutor != null) {
            tileLoadExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    long currentTime = System.currentTimeMillis();

                    ArrayList<Tile> tilesToRemove = new ArrayList<>();

                    for (Tile tile : tiles) {
//                        if (tile.getTimestamp() + cacheExpirationTime < currentTime) {
//                            tilesToRemove.add(tile);
//                        }
                    }

                    if (!tilesToRemove.isEmpty()) {
                        for (Tile tileToRemove : tilesToRemove) {
                            tiles.remove(tileToRemove);
                            deleteTileFromDatabase(tileToRemove);
                        }

                        // Обновите UI в основном потоке
                        mainThreadHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getContext(), "Старые тайлы удалены", Toast.LENGTH_SHORT).show();
                                invalidate();
                            }
                        });
                    }
                }
            });
        }
    }

    private void deleteTileFromDatabase(Tile tile) {
        if (db != null) {
            String whereClause = "x = ? AND y = ? AND scale = ?";
            String[] whereArgs = {String.valueOf(tile.getX()), String.valueOf(tile.getY()), String.valueOf(tile.getScale())};
            db.delete(TABLE_TILES, whereClause, whereArgs);
        }
    }

    public MapView(Context context, AttributeSet attrs) {
        super(context, attrs);
        p = new Paint();
        p.setStyle(Paint.Style.STROKE);
        p.setColor(Color.RED);

        setWillNotDraw(false);

        // Инициализируем базу данных SQLite
        dbHelper = new MapViewStateDatabase(context);
        db = dbHelper.getWritableDatabase();
    }

    // Добавим метод для сохранения состояния карты в базу данных
    public void saveMapViewState() {
        if (db != null) {
            // Удаляем старую запись
            db.delete("map_state", null, null);

            // Вставляем новую запись с текущими данными карты
            db.insert("map_state", null, MapViewStateDatabase.getContentValues(this));
        }
    }

    // Добавим метод для восстановления состояния карты из базы данных
    public void restoreMapViewState() {
        if (db != null) {
            Cursor cursor = db.query(
                    "map_state",
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );

            if (cursor != null && cursor.moveToFirst()) {
                MapViewStateDatabase.loadFromCursor(this, cursor);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int act = event.getAction();
        switch (act) {
            case MotionEvent.ACTION_DOWN:
                last_x = event.getX();
                last_y = event.getY();
                return true;
            case MotionEvent.ACTION_MOVE:
                float x = event.getX();
                float y = event.getY();

                float dx = x - last_x;
                float dy = y - last_y;

                offset_x += dx;
                offset_y += dy;
                invalidate();

                last_x = x;
                last_y = y;
                listener.onMove();
                return true;

            case MotionEvent.ACTION_UP:
                listener.onClick(
                        (event.getX() + abs(offset_x)) / levels[4 - current_level_index],
                        (event.getY() + abs(offset_y)) / levels[4 - current_level_index]
                );
                //  проверка что нажали на точку
                for (int i = 0; i < mapPoints.size(); i++) {
                    if (mapPoints.get(i).isThisPoint((event.getX() + abs(offset_x)) / levels[4 - current_level_index], (event.getY() + abs(offset_y)) / levels[4 - current_level_index])) {
                        listener.onPointClick(mapPoints.get(i));
                    }
                }
                return true;
        }
        return false;
    }

    boolean rect_intersects_rect(
            float ax0, float ay0, float ax1, float ay1,
            float bx0, float by0, float bx1, float by1) {
        if (ax1 < bx0) return false;
        if (ax0 < bx1) return false;
        if (ay1 < by0) return false;
        if (ay0 > by1) return false;
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onDraw(Canvas canvas) {
        width = canvas.getWidth();
        height = canvas.getHeight();

        canvas.drawColor(Color.WHITE);

        int screen_x0 = 0;
        int screen_y0 = 0;
        int screen_x1 = canvas.getWidth() - 1;
        int screen_y1 = canvas.getHeight() - 1;

        // Добавленная обработка current_level_index какие квадраты строить
        if (current_level_index >= 0 && current_level_index < levels.length) {
            int w = 0;
            int h = 0;

            if (current_level_index < x_tiles.length && current_level_index < y_tiles.length) {
                w = x_tiles[current_level_index];
                h = y_tiles[current_level_index];
            }

            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int x0 = x * tile_width + (int) offset_x;
                    int y0 = y * tile_height + (int) offset_y;
                    int x1 = x0 + tile_width;
                    int y1 = y0 + tile_height;

                    if (x0 >= screen_x1 || x1 <= screen_x0 || y0 >= screen_y1 || y1 <= screen_y0) {
                        // Пропускать рисование тайла, если он не видим на экране
                        continue;
                    }

                    Tile t = getTile(x, y, levels[current_level_index]);
                    if (t.bmp != null) {
                        canvas.drawBitmap(t.bmp, x0, y0, p);
                    }

                    canvas.drawRect(x0, y0, x1, y1, p);
                    canvas.drawText(
                            String.valueOf(levels[current_level_index]) + ", " + String.valueOf(x) + ", " + String.valueOf(y),
                            (x0 + x1) / 2,
                            (y0 + y1) / 2,
                            p
                    );
                }
            }

            Paint pointPaint = new Paint();
            pointPaint.setColor(Color.RED);
            Paint pointTextPaint = new Paint();
            pointTextPaint.setTextSize(50);
            pointTextPaint.setColor(Color.BLACK);

            for (PointDTO point : mapPoints) {
                canvas.drawCircle(point.x * levels[4 - current_level_index] + offset_x, point.y * levels[4 - current_level_index] + offset_y, 30f, pointPaint);
                canvas.drawText(point.name,point.x * levels[4 - current_level_index] + offset_x - 40, point.y * levels[4 - current_level_index] + offset_y - 40, pointTextPaint);
            }

            Paint coastlinePaint = new Paint();
            coastlinePaint.setColor(Color.DKGRAY);
            coastlinePaint.setStrokeWidth(2.0f);

            for (List<CoordinateDTO> coastLine : coastlineCoordinates) {
                for (int i = 0; i < coastLine.size() - 1; i++) {
                    canvas.drawLine(coastLine.get(i).x, coastLine.get(i).y, coastLine.get(i + 1).x, coastLine.get(i + 1).y, coastlinePaint);
                }
            }
        } else {
            // Обработка случая, когда current_level_index находится за пределами массива levels
            // Например, установка его в допустимое значение или выполнение других действий
            if (current_level_index < 0) {
                current_level_index = 0; // Установите его в минимальное допустимое значение
            } else {
                current_level_index = levels.length - 1; // Установите его в максимальное допустимое значение
            }
        }

        map = canvas;
    }

    public void refreshMap(List<PointDTO> newPoints) {
        mapPoints.clear();
        coastlineCoordinates.clear();
        mapPoints.addAll(newPoints);
        api.getCoastline(
                levels[current_level_index],
                ((map.getWidth() / 360) * (offset_x / 360)),
                ((map.getHeight() / 360) * (offset_y / 360)),
                ((map.getWidth() / 360) * ((offset_x + (map.getWidth() - 1)) / 360)),
                ((map.getHeight() / 360) * ((offset_y + (map.getHeight() - 1)) / 360))
        ).enqueue(new Callback<List<List<CoordinateDTO>>>() {
            @Override
            public void onResponse(Call<List<List<CoordinateDTO>>> call, Response<List<List<CoordinateDTO>>> response) {

                coastlineCoordinates.addAll(response.body());

                invalidate();
            }

            @Override
            public void onFailure(Call<List<List<CoordinateDTO>>> call, Throwable t) {

            }
        });
    }
}
