package fedulova.polina303.maps;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import fedulova.polina303.maps.model.PointDTO;

public class MapViewStateDatabase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "map_view_state";

    public static final String COLUMN_OFFSET_X = "offset_x";
    public static final String COLUMN_OFFSET_Y = "offset_y";
    public static final String COLUMN_CURRENT_LEVEL_INDEX = "current_level_index";

    private static final String CREATE_CASH_TABLE =
            "CREATE TABLE map_state (" +
                    COLUMN_OFFSET_X + " REAL, " +
                    COLUMN_OFFSET_Y + " REAL, " +
                    COLUMN_CURRENT_LEVEL_INDEX + " INTEGER)";

    private static final String CREATE_POINT_TABLE =
            "CREATE TABLE points (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "text TEXT," +
                    "X REAL, " +
                    "Y REAL)";

    public MapViewStateDatabase(Context context) {
        super(context, "map_database3.db", null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_CASH_TABLE);
        db.execSQL(CREATE_POINT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS map_state");
        db.execSQL("DROP TABLE IF EXISTS points");
        onCreate(db);
    }

    // Метод для получения данных состояния карты из курсора
    @SuppressLint("Range")
    public static void loadFromCursor(MapView mapView, Cursor cursor) {
        if (cursor != null) {
            mapView.offset_x = cursor.getFloat(cursor.getColumnIndex(COLUMN_OFFSET_X));
            mapView.offset_y = cursor.getFloat(cursor.getColumnIndex(COLUMN_OFFSET_Y));
            mapView.current_level_index = cursor.getInt(cursor.getColumnIndex(COLUMN_CURRENT_LEVEL_INDEX));
        }
    }

    // Метод для создания объекта ContentValues из текущего состояния карты
    public static ContentValues getContentValues(MapView mapView) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_OFFSET_X, mapView.offset_x);
        values.put(COLUMN_OFFSET_Y, mapView.offset_y);
        values.put(COLUMN_CURRENT_LEVEL_INDEX, mapView.current_level_index);
        return values;
    }

    public void addPoint(String name, Float x, Float y) {
        getWritableDatabase().execSQL("INSERT INTO points (text, X, Y) VALUES ('" + name + "', " + x + ", " + y + ");");
    }

    public List<PointDTO> getPoints() {
        ArrayList<PointDTO> points = new ArrayList<>();
        String sql = "SELECT * FROM points;";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cur = db.rawQuery(sql, null); //запустите запрос и получите результат

        if (cur.moveToFirst()) { //перейти к первой (и единственной) соответствующей записи, если это возможно
            do { //вывод всех полей
                points.add(
                        new PointDTO(
                                cur.getInt(0),
                                cur.getString(1),
                                cur.getFloat(2),
                                cur.getFloat(3)
                        )
                );
            } while (cur.moveToNext());
            return points; //возвращаемое значение из первого столбца (my_value)
        }
        return new ArrayList<>();
    }

    public void deletePoint(Integer pointId) {
        getWritableDatabase().execSQL("DELETE FROM points WHERE id = " + pointId + " ;");
    }
}
