package fedulova.polina303.maps;

import android.graphics.Point;

import fedulova.polina303.maps.model.PointDTO;

public interface OnClickToMap {

    void onClick(Float x, Float y);

    void onPointClick(PointDTO point);

    void onMove();
}
