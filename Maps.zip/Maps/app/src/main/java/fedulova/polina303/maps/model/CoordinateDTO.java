package fedulova.polina303.maps.model;

import com.google.gson.annotations.SerializedName;

public class CoordinateDTO {
    @SerializedName("x")
    public Float x;
    @SerializedName("y")
    public Float y;
}
