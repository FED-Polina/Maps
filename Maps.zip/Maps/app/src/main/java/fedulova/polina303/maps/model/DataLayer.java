package fedulova.polina303.maps.model;

import java.util.List;

public class DataLayer {
    private String name;
    private List<LineCoordinates> lines;

    public DataLayer(String name, List<LineCoordinates> lines) {
        this.name = name;
        this.lines = lines;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<LineCoordinates> getLines() {
        return lines;
    }

    public void setLines(List<LineCoordinates> lines) {
        this.lines = lines;
    }
}
