package fedulova.polina303.maps.model;

import java.util.List;

public class Map {
    private String name;
    private List<ZoomLevel> zoomLevels;
    private List<Tile> tiles;
    private List<DataLayer> dataLayers;

    public Map(String name, List<ZoomLevel> zoomLevels, List<Tile> tiles, List<DataLayer> dataLayers) {
        this.name = name;
        this.zoomLevels = zoomLevels;
        this.tiles = tiles;
        this.dataLayers = dataLayers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ZoomLevel> getZoomLevels() {
        return zoomLevels;
    }

    public void setZoomLevels(List<ZoomLevel> zoomLevels) {
        this.zoomLevels = zoomLevels;
    }

    public List<Tile> getTiles() {
        return tiles;
    }

    public void setTiles(List<Tile> tiles) {
        this.tiles = tiles;
    }

    public List<DataLayer> getDataLayers() {
        return dataLayers;
    }

    public void setDataLayers(List<DataLayer> dataLayers) {
        this.dataLayers = dataLayers;
    }
}
