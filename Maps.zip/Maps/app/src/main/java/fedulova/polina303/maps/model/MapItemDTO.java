package fedulova.polina303.maps.model;

import com.google.gson.annotations.SerializedName;

public class MapItemDTO {

    @SerializedName("level")
    Integer mapLevel;

    @SerializedName("xtiles")
    Integer xItemsCount;

    @SerializedName("ytiles")
    Integer yItemsCount;

    @SerializedName("width")
    Integer width;

    @SerializedName("height")
    Integer height;

    @SerializedName("resolution")
    Float screenResolution;

    public MapItemDTO(Integer mapLevel, Integer xItemsCount, Integer yItemsCount, Integer width, Integer height, Float screenResolution) {
        this.mapLevel = mapLevel;
        this.xItemsCount = xItemsCount;
        this.yItemsCount = yItemsCount;
        this.width = width;
        this.height = height;
        this.screenResolution = screenResolution;
    }
}
