package fedulova.polina303.maps.model;

import static java.lang.Math.abs;

public class PointDTO {

    public Integer id;
    public String name;
    public Float x;
    public Float y;

    public PointDTO(Integer id, String name, Float x, Float y) {
        this.id = id;
        this.name = name;
        this.x = x;
        this.y = y;
    }

    public Boolean isThisPoint(Float x, Float y) {
        float dx = abs(this.x - x);
        float dy = abs(this.y - y);

        return dx < 15f && dy < 15f;
    }
}
