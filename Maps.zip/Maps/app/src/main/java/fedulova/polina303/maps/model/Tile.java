package fedulova.polina303.maps.model;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;


import fedulova.polina303.maps.ApiBuilder;
import fedulova.polina303.maps.MapAPI;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//класс для описания объекта
public class Tile {
    public int scale;
    public int x;
    public int y;
    public Bitmap bmp;
    TileLoadListener loadListener; // Добавляем слушатель загрузки

    public Tile(int x, int y, int scale) {
        this.x = x;
        this.y = y;
        this.scale = scale;
        this.bmp = null;

        MapAPI api = ApiBuilder.getAPI();

        api.getTile(scale, x, y).enqueue(new Callback<TileDTO>() {
            @Override
            public void onResponse(Call<TileDTO> call, Response<TileDTO> response) {
                byte[] jpeg = Base64.decode(response.body().image, Base64.DEFAULT);
                bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length);
            }

            @Override
            public void onFailure(Call<TileDTO> call, Throwable t) {

            }
        });
    }

    // Интерфейс для слушателя загрузки
    public interface TileLoadListener {
        void onTileLoaded(Tile tile);
    }

    // Метод для установки слушателя загрузки
    public void setLoadListener(TileLoadListener listener) {
        this.loadListener = listener;
    }

    public int getScale() {
        return scale;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Bitmap getBmp() {
        return bmp;
    }

    public TileLoadListener getLoadListener() {
        return loadListener;
    }
}
