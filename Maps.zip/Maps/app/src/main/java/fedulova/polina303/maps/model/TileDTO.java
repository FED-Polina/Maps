package fedulova.polina303.maps.model;

import com.google.gson.annotations.SerializedName;

public class TileDTO {

    @SerializedName("lat")
    public
    Float lat;

    @SerializedName("lon")
    public
    Float lon;

    @SerializedName("data")
    public
    String image;

    public TileDTO(Float lat, Float lon, String image) {
        this.lat = lat;
        this.lon = lon;
        this.image = image;
    }
}
