package fedulova.polina303.maps.model;

public class ZoomLevel {
    private int level;
    private int tileWidth;
    private int tileHeight;

    public ZoomLevel(int level, int tileWidth, int tileHeight) {
        this.level = level;
        this.tileWidth = tileWidth;
        this.tileHeight = tileHeight;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getTileWidth() {
        return tileWidth;
    }

    public void setTileWidth(int tileWidth) {
        this.tileWidth = tileWidth;
    }

    public int getTileHeight() {
        return tileHeight;
    }

    public void setTileHeight(int tileHeight) {
        this.tileHeight = tileHeight;
    }
}
