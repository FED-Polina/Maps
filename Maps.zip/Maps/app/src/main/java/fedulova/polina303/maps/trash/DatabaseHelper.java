package fedulova.polina303.maps.trash;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "app_settings.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_SETTINGS = "settings";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_KEY = "key";
    private static final String COLUMN_VALUE = "value";
    private static final String COLUMN_TILE_ID = "tile_id";
    private static final String COLUMN_TILE_IMAGE = "tile_image";
    private static final String COLUMN_TILE_TIMESTAMP = "tile_timestamp";
    public static final String TABLE_TILES = "tiles";

    // SQL-запрос для создания таблицы тайлов
    private static final String CREATE_TABLE_TILES = "CREATE TABLE " + TABLE_TILES + " (" +
            COLUMN_TILE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_KEY + " TEXT NOT NULL, " +
            COLUMN_TILE_IMAGE + " BLOB, " +
            COLUMN_TILE_TIMESTAMP + " INTEGER);";

    // Метод для удаления старых тайлов
    public void deleteExpiredTiles(long currentTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COLUMN_TILE_TIMESTAMP + " < ?";
        String[] whereArgs = {String.valueOf(currentTime)};
        db.delete(TABLE_TILES, whereClause, whereArgs);
        db.close();
    }


    // SQL-запрос для создания таблицы
    private static final String CREATE_TABLE_SETTINGS = "CREATE TABLE " + TABLE_SETTINGS + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_KEY + "TEXT NOT NULL, " +
            COLUMN_VALUE + " TEXT);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Создание таблицы при первом запуске
        db.execSQL(CREATE_TABLE_SETTINGS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Обновление базы данных (если необходимо)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTINGS);
        onCreate(db);
    }

    // Добавление новой записи в таблицу
    public long insertSetting(String key, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_KEY, key);
        values.put(COLUMN_VALUE, value);
        long id = db.insert(TABLE_SETTINGS, null, values);
        db.close();
        return id;
    }

    // Получение значения настройки по ключу
    @SuppressLint("Range")
    public String getSettingValue(String key) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {COLUMN_VALUE};
        String selection = COLUMN_KEY + "=?";
        String[] selectionArgs = {key};
        Cursor cursor = db.query(TABLE_SETTINGS, projection, selection, selectionArgs, null, null, null);
        String value = null;
        if (cursor.moveToFirst()) {
            value = cursor.getString(cursor.getColumnIndex(COLUMN_VALUE));
        }
        cursor.close();
        db.close();
        return value;
    }

    // Обновление значения настройки по ключу
    public int updateSettingValue(String key, String newValue) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_VALUE, newValue);
        String whereClause = COLUMN_KEY + "=?";
        String[] whereArgs = {key};
        int rowsUpdated = db.update(TABLE_SETTINGS, values, whereClause, whereArgs);
        db.close();
        return rowsUpdated;
    }

    // Удаление настройки по ключу
    public void deleteSetting(String key) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COLUMN_KEY + "=?";
        String[] whereArgs = {key};
        db.delete(TABLE_SETTINGS, whereClause, whereArgs);
        db.close();
    }
}
