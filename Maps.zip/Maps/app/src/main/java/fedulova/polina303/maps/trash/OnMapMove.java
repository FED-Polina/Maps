package fedulova.polina303.maps.trash;

public interface OnMapMove {
    void onMove();
}
